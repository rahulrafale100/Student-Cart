
public class Users {
	private int id;
	private String name;
	private String mobileNo;
	private String emailID;
	private String uname;
	private String password;
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getmobileNo() {
		return mobileNo;
	}
	public String getUserName() {
		return uname;
	}
	public String getPassword() {
		return password;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setId(int x) {
	 id=x;
	}
	public void setName(String x) {
		 name=x;
	}
	public void setmobileNo(String x) {
		mobileNo=x;
	}
	public void setUserName(String x) {
	 uname=x;
	}
	public void setPassword(String x) {
		 password=x;
	}
	public void setEmailid(String x) {
		emailID=x;
	}
	public void login() {
		
	}
	public void register() {
		
	}
}
