
public class Category {
	private int id;
	private String name;
	private String description;
	void setId(int x) {
		id=x;
	}
	void setName(String x) {
		name=x;
	}
	void setDes(String x) {
		description=x;
	}
	int getId(int x) {
		return id;
	}
	String getName(String x) {
		return name;
	}
	String getDes(String x) {
		return description;
	}
	
}
